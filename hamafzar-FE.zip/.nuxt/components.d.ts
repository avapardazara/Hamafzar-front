
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const DataTable: typeof import("../app/components/data/DataTable.vue")['default']
export const FeedbackToast: typeof import("../app/components/feedback/Toast.vue")['default']
export const LayoutHafSidebar: typeof import("../app/components/layout/HafSidebar.vue")['default']
export const LayoutHeader: typeof import("../app/components/layout/Header.vue")['default']
export const LayoutThemeToggle: typeof import("../app/components/layout/ThemeToggle.vue")['default']
export const LayoutAuth: typeof import("../app/components/layout/auth.vue")['default']
export const LayoutDefault: typeof import("../app/components/layout/default.vue")['default']
export const UiAtomsButton: typeof import("../app/components/ui/atoms/Button.vue")['default']
export const UiAtomsCard: typeof import("../app/components/ui/atoms/Card.vue")['default']
export const UiAtomsFormField: typeof import("../app/components/ui/atoms/FormField.vue")['default']
export const UiAtomsInputText: typeof import("../app/components/ui/atoms/InputText.vue")['default']
export const UiAtomsSpinner: typeof import("../app/components/ui/atoms/Spinner.vue")['default']
export const UiMoleculesCheckbox: typeof import("../app/components/ui/molecules/Checkbox.vue")['default']
export const UiMoleculesCombobox: typeof import("../app/components/ui/molecules/Combobox.vue")['default']
export const UiMoleculesDatePickerJalali: typeof import("../app/components/ui/molecules/DatePickerJalali.vue")['default']
export const UiMoleculesFormField: typeof import("../app/components/ui/molecules/FormField.vue")['default']
export const UiMoleculesInputText: typeof import("../app/components/ui/molecules/InputText.vue")['default']
export const UiMoleculesPagination: typeof import("../app/components/ui/molecules/Pagination.vue")['default']
export const UiMoleculesRadio: typeof import("../app/components/ui/molecules/Radio.vue")['default']
export const UiMoleculesSearchBar: typeof import("../app/components/ui/molecules/SearchBar.vue")['default']
export const UiMoleculesSelect: typeof import("../app/components/ui/molecules/Select.vue")['default']
export const UiMoleculesSwitch: typeof import("../app/components/ui/molecules/Switch.vue")['default']
export const UiOrganismsDrawer: typeof import("../app/components/ui/organisms/Drawer.vue")['default']
export const UiOrganismsModal: typeof import("../app/components/ui/organisms/Modal.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyDataTable: LazyComponent<typeof import("../app/components/data/DataTable.vue")['default']>
export const LazyFeedbackToast: LazyComponent<typeof import("../app/components/feedback/Toast.vue")['default']>
export const LazyLayoutHafSidebar: LazyComponent<typeof import("../app/components/layout/HafSidebar.vue")['default']>
export const LazyLayoutHeader: LazyComponent<typeof import("../app/components/layout/Header.vue")['default']>
export const LazyLayoutThemeToggle: LazyComponent<typeof import("../app/components/layout/ThemeToggle.vue")['default']>
export const LazyLayoutAuth: LazyComponent<typeof import("../app/components/layout/auth.vue")['default']>
export const LazyLayoutDefault: LazyComponent<typeof import("../app/components/layout/default.vue")['default']>
export const LazyUiAtomsButton: LazyComponent<typeof import("../app/components/ui/atoms/Button.vue")['default']>
export const LazyUiAtomsCard: LazyComponent<typeof import("../app/components/ui/atoms/Card.vue")['default']>
export const LazyUiAtomsFormField: LazyComponent<typeof import("../app/components/ui/atoms/FormField.vue")['default']>
export const LazyUiAtomsInputText: LazyComponent<typeof import("../app/components/ui/atoms/InputText.vue")['default']>
export const LazyUiAtomsSpinner: LazyComponent<typeof import("../app/components/ui/atoms/Spinner.vue")['default']>
export const LazyUiMoleculesCheckbox: LazyComponent<typeof import("../app/components/ui/molecules/Checkbox.vue")['default']>
export const LazyUiMoleculesCombobox: LazyComponent<typeof import("../app/components/ui/molecules/Combobox.vue")['default']>
export const LazyUiMoleculesDatePickerJalali: LazyComponent<typeof import("../app/components/ui/molecules/DatePickerJalali.vue")['default']>
export const LazyUiMoleculesFormField: LazyComponent<typeof import("../app/components/ui/molecules/FormField.vue")['default']>
export const LazyUiMoleculesInputText: LazyComponent<typeof import("../app/components/ui/molecules/InputText.vue")['default']>
export const LazyUiMoleculesPagination: LazyComponent<typeof import("../app/components/ui/molecules/Pagination.vue")['default']>
export const LazyUiMoleculesRadio: LazyComponent<typeof import("../app/components/ui/molecules/Radio.vue")['default']>
export const LazyUiMoleculesSearchBar: LazyComponent<typeof import("../app/components/ui/molecules/SearchBar.vue")['default']>
export const LazyUiMoleculesSelect: LazyComponent<typeof import("../app/components/ui/molecules/Select.vue")['default']>
export const LazyUiMoleculesSwitch: LazyComponent<typeof import("../app/components/ui/molecules/Switch.vue")['default']>
export const LazyUiOrganismsDrawer: LazyComponent<typeof import("../app/components/ui/organisms/Drawer.vue")['default']>
export const LazyUiOrganismsModal: LazyComponent<typeof import("../app/components/ui/organisms/Modal.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]
