
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  'DataTable': typeof import("../../app/components/data/DataTable.vue")['default']
  'FeedbackToast': typeof import("../../app/components/feedback/Toast.vue")['default']
  'LayoutHafSidebar': typeof import("../../app/components/layout/HafSidebar.vue")['default']
  'LayoutHeader': typeof import("../../app/components/layout/Header.vue")['default']
  'LayoutThemeToggle': typeof import("../../app/components/layout/ThemeToggle.vue")['default']
  'LayoutAuth': typeof import("../../app/components/layout/auth.vue")['default']
  'LayoutDefault': typeof import("../../app/components/layout/default.vue")['default']
  'UiAtomsButton': typeof import("../../app/components/ui/atoms/Button.vue")['default']
  'UiAtomsCard': typeof import("../../app/components/ui/atoms/Card.vue")['default']
  'UiAtomsFormField': typeof import("../../app/components/ui/atoms/FormField.vue")['default']
  'UiAtomsInputText': typeof import("../../app/components/ui/atoms/InputText.vue")['default']
  'UiAtomsSpinner': typeof import("../../app/components/ui/atoms/Spinner.vue")['default']
  'UiMoleculesCheckbox': typeof import("../../app/components/ui/molecules/Checkbox.vue")['default']
  'UiMoleculesCombobox': typeof import("../../app/components/ui/molecules/Combobox.vue")['default']
  'UiMoleculesDatePickerJalali': typeof import("../../app/components/ui/molecules/DatePickerJalali.vue")['default']
  'UiMoleculesFormField': typeof import("../../app/components/ui/molecules/FormField.vue")['default']
  'UiMoleculesInputText': typeof import("../../app/components/ui/molecules/InputText.vue")['default']
  'UiMoleculesPagination': typeof import("../../app/components/ui/molecules/Pagination.vue")['default']
  'UiMoleculesRadio': typeof import("../../app/components/ui/molecules/Radio.vue")['default']
  'UiMoleculesSearchBar': typeof import("../../app/components/ui/molecules/SearchBar.vue")['default']
  'UiMoleculesSelect': typeof import("../../app/components/ui/molecules/Select.vue")['default']
  'UiMoleculesSwitch': typeof import("../../app/components/ui/molecules/Switch.vue")['default']
  'UiOrganismsDrawer': typeof import("../../app/components/ui/organisms/Drawer.vue")['default']
  'UiOrganismsModal': typeof import("../../app/components/ui/organisms/Modal.vue")['default']
  'NuxtWelcome': typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']
  'NuxtLayout': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
  'NuxtErrorBoundary': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
  'ClientOnly': typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']
  'DevOnly': typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']
  'ServerPlaceholder': typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']
  'NuxtLink': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']
  'NuxtLoadingIndicator': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
  'NuxtTime': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
  'NuxtRouteAnnouncer': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
  'NuxtImg': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
  'NuxtPicture': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
  'NuxtPage': typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']
  'NoScript': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']
  'Link': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']
  'Base': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']
  'Title': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']
  'Meta': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']
  'Style': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']
  'Head': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']
  'Html': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']
  'Body': typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']
  'NuxtIsland': typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']
  'LazyDataTable': LazyComponent<typeof import("../../app/components/data/DataTable.vue")['default']>
  'LazyFeedbackToast': LazyComponent<typeof import("../../app/components/feedback/Toast.vue")['default']>
  'LazyLayoutHafSidebar': LazyComponent<typeof import("../../app/components/layout/HafSidebar.vue")['default']>
  'LazyLayoutHeader': LazyComponent<typeof import("../../app/components/layout/Header.vue")['default']>
  'LazyLayoutThemeToggle': LazyComponent<typeof import("../../app/components/layout/ThemeToggle.vue")['default']>
  'LazyLayoutAuth': LazyComponent<typeof import("../../app/components/layout/auth.vue")['default']>
  'LazyLayoutDefault': LazyComponent<typeof import("../../app/components/layout/default.vue")['default']>
  'LazyUiAtomsButton': LazyComponent<typeof import("../../app/components/ui/atoms/Button.vue")['default']>
  'LazyUiAtomsCard': LazyComponent<typeof import("../../app/components/ui/atoms/Card.vue")['default']>
  'LazyUiAtomsFormField': LazyComponent<typeof import("../../app/components/ui/atoms/FormField.vue")['default']>
  'LazyUiAtomsInputText': LazyComponent<typeof import("../../app/components/ui/atoms/InputText.vue")['default']>
  'LazyUiAtomsSpinner': LazyComponent<typeof import("../../app/components/ui/atoms/Spinner.vue")['default']>
  'LazyUiMoleculesCheckbox': LazyComponent<typeof import("../../app/components/ui/molecules/Checkbox.vue")['default']>
  'LazyUiMoleculesCombobox': LazyComponent<typeof import("../../app/components/ui/molecules/Combobox.vue")['default']>
  'LazyUiMoleculesDatePickerJalali': LazyComponent<typeof import("../../app/components/ui/molecules/DatePickerJalali.vue")['default']>
  'LazyUiMoleculesFormField': LazyComponent<typeof import("../../app/components/ui/molecules/FormField.vue")['default']>
  'LazyUiMoleculesInputText': LazyComponent<typeof import("../../app/components/ui/molecules/InputText.vue")['default']>
  'LazyUiMoleculesPagination': LazyComponent<typeof import("../../app/components/ui/molecules/Pagination.vue")['default']>
  'LazyUiMoleculesRadio': LazyComponent<typeof import("../../app/components/ui/molecules/Radio.vue")['default']>
  'LazyUiMoleculesSearchBar': LazyComponent<typeof import("../../app/components/ui/molecules/SearchBar.vue")['default']>
  'LazyUiMoleculesSelect': LazyComponent<typeof import("../../app/components/ui/molecules/Select.vue")['default']>
  'LazyUiMoleculesSwitch': LazyComponent<typeof import("../../app/components/ui/molecules/Switch.vue")['default']>
  'LazyUiOrganismsDrawer': LazyComponent<typeof import("../../app/components/ui/organisms/Drawer.vue")['default']>
  'LazyUiOrganismsModal': LazyComponent<typeof import("../../app/components/ui/organisms/Modal.vue")['default']>
  'LazyNuxtWelcome': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
  'LazyNuxtLayout': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
  'LazyNuxtErrorBoundary': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
  'LazyClientOnly': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']>
  'LazyDevOnly': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']>
  'LazyServerPlaceholder': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
  'LazyNuxtLink': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
  'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
  'LazyNuxtTime': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
  'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
  'LazyNuxtImg': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
  'LazyNuxtPicture': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
  'LazyNuxtPage': LazyComponent<typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']>
  'LazyNoScript': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
  'LazyLink': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']>
  'LazyBase': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']>
  'LazyTitle': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']>
  'LazyMeta': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']>
  'LazyStyle': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']>
  'LazyHead': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']>
  'LazyHtml': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']>
  'LazyBody': LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']>
  'LazyNuxtIsland': LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
