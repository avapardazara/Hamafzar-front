<script setup lang="ts">
import { ref, reactive, watch } from 'vue'
import Card from '../../../components/ui/atoms/Card.vue'
import DataTable from '../../../components/data/DataTable.vue'
import SearchBar from '../../../components/ui/molecules/SearchBar.vue'
import Pagination from '../../../components/ui/molecules/Pagination.vue'
import DatePickerJalali from '../../../components/ui/molecules/DatePickerJalali.vue'
import { useServerTable } from '../../../composables/data/useServerTable'
import { jalaliToGregorianStr } from '../../../utils/jalali-lite'

type Course = { id: number; title: string; start_date?: string; end_date?: string }

// فیلترهای UI (جلالی در UI، میلادی برای API)
const ui = reactive({
  level: '',
  start_from_j: null as string | null, // مثال: "1404/08/19"
  start_to_j:   null as string | null
})

// جدول سروری
const tbl = useServerTable<Course, {
  search?: string
  level?: string
  start_from?: string | null // "YYYY-MM-DD"
  start_to?: string | null   // "YYYY-MM-DD"
}>({
  endpoint: '/courses',
  initialSort: { key: 'title', dir: 'asc' },
  initialFilter: {
    level: '',
    start_from: null,
    start_to: null
  },
  // اگر ساختار پاسخ API متفاوت است، اینجا map کن:
  // mapResponse: (res) => ({ items: res.items, total: res.total })
})

// سطح دوره (نمونه)
const levels = [
  { value: '', label: 'همه سطوح' },
  { value: 'basic', label: 'مبتدی' },
  { value: 'intermediate', label: 'متوسط' },
  { value: 'advanced', label: 'پیشرفته' },
]

// سینک کردن فیلتر تاریخ‌ها: جلالی UI → میلادی API
watch(() => ui.start_from_j, (j) => {
  (tbl.filters.value as any).start_from = j ? jalaliToGregorianStr(j) : null
  tbl.go(1)
})
watch(() => ui.start_to_j, (j) => {
  (tbl.filters.value as any).start_to = j ? jalaliToGregorianStr(j) : null
  tbl.go(1)
})

// تغییر سطح
watch(() => ui.level, (v) => {
  (tbl.filters.value as any).level = v || ''
  tbl.go(1)
})
</script>

<template>
  <div class="grid gap-6">
    <Card>
      <template #header>
        <div class="flex flex-col gap-3">
          <div class="flex items-center justify-between gap-3">
            <h2 class="text-lg font-bold">دوره‌ها</h2>
            <SearchBar v-model="tbl.search" placeholder="جستجوی عنوان دوره..." />
          </div>

          <!-- فیلترها -->
          <div class="grid gap-3 md:grid-cols-3">
            <!-- سطح دوره -->
            <div>
              <label class="text-sm font-medium block mb-1">سطح دوره</label>
              <select
                v-model="ui.level"
                class="w-full h-10 rounded-xl border border-border/60 dark:border-white/15 bg-white dark:bg-[#0f172a] px-3 text-sm"
              >
                <option v-for="opt in levels" :key="opt.value" :value="opt.value">{{ opt.label }}</option>
              </select>
            </div>

            <!-- تاریخ شروع از (جلالی) -->
            <div>
              <label class="text-sm font-medium block mb-1">تاریخ شروع از</label>
              <DatePickerJalali v-model="ui.start_from_j" />
            </div>

            <!-- تاریخ شروع تا (جلالی) -->
            <div>
              <label class="text-sm font-medium block mb-1">تاریخ شروع تا</label>
              <DatePickerJalali v-model="ui.start_to_j" />
            </div>
          </div>
        </div>
      </template>

      <DataTable
        :columns="[
          { key: 'title',      label: 'عنوان دوره' },
          { key: 'start_date', label: 'شروع (میلادی)' },
          { key: 'end_date',   label: 'پایان (میلادی)' },
        ]"
        :rows="tbl.rows"
        :loading="tbl.loading"
        :error="tbl.error"
      >
        <!-- سورت: با کلیک روی عنوان ستون title سوییچ می‌کنیم -->
        <template #toolbar>
          <div class="text-xs text-gray-500">
            مرتب‌سازی:
            <button class="underline mr-2" @click="tbl.setSort('title')">
              عنوان
              <span v-if="tbl.sortKey==='title'">({{ tbl.sortDir || '—' }})</span>
            </button>
          </div>
        </template>

        <template #cell:start_date="{ row }">
          {{ row.start_date ?? '—' }}
        </template>
        <template #cell:end_date="{ row }">
          {{ row.end_date ?? '—' }}
        </template>

        <template #pagination>
          <Pagination
            :page="tbl.page"
            :pageCount="tbl.pageCount"
            :total="tbl.total"
            :canPrev="tbl.canPrev"
            :canNext="tbl.canNext"
            :pageSize="tbl.pageSize"
            @prev="tbl.prev()"
            @next="tbl.next()"
            @update:pageSize="(v:number)=>{ tbl.pageSize = v; tbl.go(1) }"
          />
        </template>
      </DataTable>
    </Card>
  </div>
</template>
