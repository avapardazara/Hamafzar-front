<template>
  <section class="p-6">
    <h1 class="text-2xl font-bold">بخش مالی</h1>
    <p class="mt-2 text-slate-600">اینجا بعداً لیست پرداخت‌ها/اقساط میاد.</p>
  </section>
</template>

<script setup>
definePageMeta({ middleware: ['auth'] })
</script>
