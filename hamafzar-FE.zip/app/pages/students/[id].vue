<template>
  <section class="haf-student-profile" dir="rtl">
    <!-- هدر بالا + دکمه برگشت -->
    <header class="haf-student-profile__header">
      <div class="haf-student-profile__title-wrap">
        <button type="button" class="haf-btn haf-btn--ghost haf-btn--sm" @click="goBack">
          ← بازگشت به لیست
        </button>
        <div>
          <h1 class="haf-student-profile__title">
            پروفایل دانشجو
          </h1>
          <p class="haf-student-profile__subtitle" v-if="student">
            {{ student.full_name || (student.first_name + ' ' + student.last_name) }}
            <span class="haf-student-profile__id">ID: {{ student.id }}</span>
          </p>
        </div>
      </div>

      <div class="haf-student-profile__header-actions" v-if="student">
        <button type="button" class="haf-btn haf-btn--outline" @click="goToEdit">
          ✏️ ویرایش اطلاعات
        </button>
      </div>
    </header>

    <!-- وضعیت لودینگ / خطا -->
    <section v-if="loading" class="haf-card haf-card--soft haf-mt">
      در حال بارگذاری پروفایل دانشجو...
    </section>
    <section v-else-if="error" class="haf-card haf-card--danger haf-mt">
      {{ error }}
    </section>

    <section v-else-if="student" class="haf-student-profile__body haf-mt">
      <!-- ستون اصلی + ستون ساید -->
      <div class="haf-student-profile__grid">
        <!-- ستون اصلی -->
        <div class="haf-student-profile__main">
          <!-- کارت هویت و مشخصات -->
          <section class="haf-card haf-student-identity">
            <div class="haf-student-identity__header">
              <div class="haf-avatar-lg">
                <span>{{ getInitials(student) }}</span>
              </div>
              <div>
                <h2 class="haf-student-identity__name">
                  {{ student.full_name || (student.first_name + ' ' + student.last_name) }}
                </h2>
                <p class="haf-student-identity__meta">
                  موبایل:
                  <span class="haf-mono">{{ student.phone || '—' }}</span>
                  · کد ملی:
                  <span class="haf-mono">{{ student.national_code || '—' }}</span>
                </p>
              </div>
            </div>

            <dl class="haf-student-identity__details">
              <div class="haf-detail-row">
                <dt>ایمیل</dt>
                <dd>{{ student.email || 'ثبت نشده' }}</dd>
              </div>
              <div class="haf-detail-row">
                <dt>آدرس</dt>
                <dd>{{ student.address || 'ثبت نشده' }}</dd>
              </div>
              <div class="haf-detail-row">
                <dt>یادداشت داخلی</dt>
                <dd>{{ student.note || '—' }}</dd>
              </div>
              <div class="haf-detail-row">
                <dt>وضعیت</dt>
                <dd>
                  <span
                    class="haf-status-pill"
                    :data-variant="student.status || 'active'"
                  >
                    {{ student.status === 'inactive' ? 'غیرفعال' : 'فعال' }}
                  </span>
                </dd>
              </div>
              <div class="haf-detail-row">
                <dt>تاریخ ایجاد</dt>
                <dd>{{ formatDate(student.created_at) }}</dd>
              </div>
            </dl>
          </section>

          <!-- تب‌ها -->
          <section class="haf-tabs haf-mt-lg">
            <!-- دکمه‌های تب -->
            <div class="haf-tabs__list">
              <button
                type="button"
                class="haf-tabs__btn"
                :class="{ 'haf-tabs__btn--active': activeTab === 'overview' }"
                @click="activeTab = 'overview'"
              >
                نمای کلی
              </button>
              <button
                type="button"
                class="haf-tabs__btn"
                :class="{ 'haf-tabs__btn--active': activeTab === 'finance' }"
                @click="activeTab = 'finance'"
              >
                مالی و اقساط
              </button>
              <button
                type="button"
                class="haf-tabs__btn"
                :class="{ 'haf-tabs__btn--active': activeTab === 'activity' }"
                @click="activeTab = 'activity'"
              >
                فعالیت و دوره‌ها
              </button>
            </div>

            <!-- محتوای تب‌ها -->
            <div class="haf-tabs__panels">
              <!-- تب نمای کلی -->
              <section
                v-if="activeTab === 'overview'"
                class="haf-tabs__panel"
              >
                <h3 class="haf-tabs__panel-title">نمای کلی دانشجو</h3>
                <p class="haf-tabs__panel-desc">
                  خلاصه‌ای از اطلاعات و وضعیت فعلی دانشجو در سیستم هم‌افزار.
                </p>

                <div class="haf-grid-2 haf-mt">
                  <div class="haf-card haf-card--soft">
                    <h4 class="haf-card__title">اطلاعات تماس</h4>
                    <dl class="haf-detail-list">
                      <div class="haf-detail-row">
                        <dt>موبایل</dt>
                        <dd class="haf-mono">{{ student.phone || 'ثبت نشده' }}</dd>
                      </div>
                      <div class="haf-detail-row">
                        <dt>ایمیل</dt>
                        <dd>{{ student.email || 'ثبت نشده' }}</dd>
                      </div>
                      <div class="haf-detail-row">
                        <dt>آدرس</dt>
                        <dd>{{ student.address || 'ثبت نشده' }}</dd>
                      </div>
                    </dl>
                  </div>

                  <div class="haf-card haf-card--soft">
                    <h4 class="haf-card__title">وضعیت سیستم</h4>
                    <dl class="haf-detail-list">
                      <div class="haf-detail-row">
                        <dt>تاریخ ایجاد پروفایل</dt>
                        <dd>{{ formatDate(student.created_at) }}</dd>
                      </div>
                      <div class="haf-detail-row">
                        <dt>شناسه سیستم</dt>
                        <dd class="haf-mono">#{{ student.id }}</dd>
                      </div>
                      <div class="haf-detail-row">
                        <dt>وضعیت حساب</dt>
                        <dd>
                          <span
                            class="haf-status-pill"
                            :data-variant="student.status || 'active'"
                          >
                            {{ student.status === 'inactive' ? 'غیرفعال' : 'فعال' }}
                          </span>
                        </dd>
                      </div>
                    </dl>
                  </div>
                </div>
              </section>

              <!-- تب مالی -->
              <section
                v-else-if="activeTab === 'finance'"
                class="haf-tabs__panel"
              >
                <h3 class="haf-tabs__panel-title">وضعیت مالی و اقساط</h3>
                <p class="haf-tabs__panel-desc">
                  این بخش در نسخه فعلی به صورت نمایشی است؛ بعداً به API مالی متصل می‌کنیم.
                </p>

                <div class="haf-metrics-grid haf-mt">
                  <div class="haf-metric-card">
                    <p class="haf-metric-card__label">مانده حساب</p>
                    <p class="haf-metric-card__value">
                      {{ formatNumber(finance?.totals?.balance || 0) }} تومان
                    </p>
                  </div>
                  <div class="haf-metric-card">
                    <p class="haf-metric-card__label">اقساط فعال</p>
                    <p class="haf-metric-card__value">
                      {{ formatNumber(finance?.totals?.installments_active || 0) }} قسط
                    </p>
                  </div>
                  <div class="haf-metric-card">
                    <p class="haf-metric-card__label">مبلغ پرداخت‌شده</p>
                    <p class="haf-metric-card__value">
                      {{ formatNumber(finance?.totals?.paid || 0) }} تومان
                    </p>
                  </div>
                </div>

                <div class="haf-card haf-card--soft haf-mt">
                  <h4 class="haf-card__title">ریز اقساط / تراکنش‌ها</h4>
                  <p class="haf-empty-state">
                    اتصال این بخش به بک‌اند در مرحله بعدی انجام می‌شود.
                  </p>
                </div>
              </section>

              <!-- تب فعالیت -->
              <section
                v-else-if="activeTab === 'activity'"
                class="haf-tabs__panel"
              >
                <h3 class="haf-tabs__panel-title">دوره‌ها و فعالیت‌ها</h3>
                <p class="haf-tabs__panel-desc">
                  در این بخش می‌توان سابقه حضور در دوره‌ها، جلسات و فعال‌بودن در برنامه‌ها را دید.
                </p>

                <div class="haf-card haf-card--soft haf-mt">
                  <p class="haf-empty-state">
                    این بخش فعلاً به صورت placeholder است و بعداً به ماژول دوره‌ها و حضور و غیاب متصل می‌شود.
                  </p>
                </div>
              </section>
            </div>
          </section>
        </div>

        <!-- ستون ساید (خلاصه) -->
        <aside class="haf-student-profile__aside">
          <section class="haf-card haf-card--glass">
            <h3 class="haf-card__title">خلاصه وضعیت</h3>
            <ul class="haf-summary-list">
              <li>
                <span>دوره‌های فعال</span>
                <strong>{{ formatNumber(stats?.courses_count || 0) }}</strong>
              </li>
              <li>
                <span>مهارت‌های ثبت‌شده</span>
                <strong>{{ formatNumber(stats?.skills_count || 0) }}</strong>
              </li>
              <li>
                <span>مانده حساب</span>
                <strong>{{ formatNumber(stats?.balance || 0) }} تومان</strong>
              </li>
            </ul>
          </section>
        </aside>
      </div>
    </section>

    <section v-else class="haf-card haf-mt">
      دانشجو پیدا نشد.
    </section>
  </section>
</template>

<script setup>
import './students.page.css'
import { useStudentProfile } from './students.page.js'

definePageMeta({
  middleware: ['auth'],
})

const {
  loading,
  error,
  student,
  registrations,
  payments,
  totalPaid,
  formatNumber,
  formatDate,
  getInitials,
  goBack,
} = useStudentProfile()
</script>