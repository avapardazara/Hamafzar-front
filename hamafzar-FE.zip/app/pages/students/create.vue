<template>
  <section class="haf-profile-page" dir="rtl">


    <div class="haf-profile-container">

      <!-- Sidebar -->
      <aside class="haf-profile-side">
        <div class="haf-avatar-box">
          <img v-if="avatarPreview" :src="avatarPreview" class="haf-avatar-img" />
          <div v-else class="haf-avatar-placeholder">?</div>

          <label class="haf-avatar-upload">
            📷
            <input type="file" @change="onAvatarChange" accept="image/*" hidden>
          </label>
        </div>

        <h3 class="haf-profile-name">
          {{ form.first_name || 'نام' }} {{ form.last_name || '' }}
        </h3>

        <p class="haf-profile-id">دانشجو جدید</p>

        <p class="haf-profile-date">در انتظار ایجاد...</p>
      </aside>

      <!-- Form -->
      <section class="haf-profile-form">
        
        <h2 class="haf-form-title">اطلاعات دانشجو</h2>

        <div class="haf-grid">

          <div class="haf-field">
            <label>نام</label>
            <input v-model="form.first_name" class="haf-input" type="text" />
          </div>

          <div class="haf-field">
            <label>نام خانوادگی</label>
            <input v-model="form.last_name" class="haf-input" type="text" />
          </div>

          <div class="haf-field">
            <label>شماره موبایل</label>
            <input v-model="form.phone" class="haf-input" type="text" />
          </div>

          <div class="haf-field">
            <label>کد ملی</label>
            <input v-model="form.national_code" class="haf-input" type="text" />
          </div>

          <div class="haf-field">
            <label>ایمیل</label>
            <input v-model="form.email" class="haf-input" type="email" />
          </div>

          <div class="haf-field haf-field--full">
            <label>توضیحات</label>
            <textarea v-model="form.notes" rows="3" class="haf-input"></textarea>
          </div>

        </div>

        <!-- Actions -->
        <div class="haf-actions">
          <button class="haf-btn haf-btn--ghost" @click="cancel">لغو</button>
          <button class="haf-btn haf-btn--primary" @click="onSubmit">
            ذخیره
          </button>
        </div>

      </section>

    </div>
  </section>
</template>
<script setup>
import './students.page.css'
import { useStudentForm } from './students.page.js'

definePageMeta({
  middleware: ['auth'],
})

const {
  form,
  loading,
  saving,
  error,
  onSubmit,
  autoFullName,
} = useStudentForm()
</script>
