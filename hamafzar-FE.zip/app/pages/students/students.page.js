// app/pages/students/students.page.js
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useCookie } from '#app'

const API_BASE = 'http://localhost:5000'

// هدرهای احراز هویت برای تمام درخواست‌های دانشجوها
function getAuthHeaders () {
  const token = useCookie('ha_token', { path: '/' })
  const headers = {
    Accept: 'application/json',
    'Content-Type': 'application/json'
  }

  if (token.value) {
    headers.Authorization = `Bearer ${token.value}`
  } else {
    console.warn('[students] no ha_token cookie, request will probably be 401')
  }

  return headers
}

// فرمت سه‌رقمی عدد
function formatNumber (n) {
  if (n == null) return ''
  return new Intl.NumberFormat('fa-IR').format(n)
}

// تبدیل تاریخ ISO به شمسی ساده (یا نمایش خط تیره)
function formatDate (iso) {
  if (!iso) return '—'
  try {
    const d = new Date(iso)
    if (Number.isNaN(d.getTime())) return '—'
    // فقط نمایشی؛ بعداً می‌تونیم به jalaali کامل وصل کنیم
    return d.toLocaleDateString('fa-IR')
  } catch {
    return '—'
  }
}

// حروف اول اسم برای آواتار
function getInitials (s) {
  if (!s) return '؟'
  const name = s.full_name || `${s.first_name || ''} ${s.last_name || ''}`.trim()
  if (!name) return '؟'
  return name[0]
}

/* =========================================================================
   لیست دانشجوها
   ========================================================================= */
export default function useStudents () {
  const router = useRouter()
  const route = useRoute()

  const students = ref([])
  const loading = ref(false)
  const total = ref(0)

  const filters = reactive({
    q: '',
    date_from: '',
    date_to: ''
  })

  const fromDateInput = ref(null)
  const toDateInput = ref(null)

  async function fetchStudents () {
    loading.value = true

    try {
      const params = new URLSearchParams()

      if (filters.q) params.append('q', filters.q)
      if (filters.date_from) params.append('date_from', filters.date_from)
      if (filters.date_to) params.append('date_to', filters.date_to)

      const url = `${API_BASE}/api/students${params.toString() ? `?${params.toString()}` : ''}`
      console.log('[students] fetch URL:', url)

      const res = await fetch(url, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include' // 🔴 حتماً برای ارسال کوکی سشن / JWT
      })

      let data = null
      try {
        data = await res.json()
      } catch (e) {
        console.warn('[students] cannot parse JSON', e)
      }

      console.log('[students] status:', res.status)
      console.log('[students] raw data:', data)

      if (!res.ok) {
        // اگر 401 بود، کاربر رو به لاگین برگردونیم
        if (res.status === 401) {
          console.warn('[students] 401 unauthorized → redirect to login')
          await router.push(`/auth/login?redirect=${encodeURIComponent(route.fullPath || '/students')}`)
        } else {
          console.warn('[students] backend returned error status', res.status, data)
        }
        return
      }

      const items = data?.items || data?.students || []
      students.value = Array.isArray(items) ? items : []
      total.value = data?.total ?? students.value.length
    } catch (err) {
      console.error('[students] list fetch error', err)
    } finally {
      loading.value = false
    }
  }

  function resetFilters () {
    filters.q = ''
    filters.date_from = ''
    filters.date_to = ''
    fetchStudents()
  }

  function onCreate () {
    router.push('/students/create')
  }

  function onRefresh () {
    fetchStudents()
  }

  function goToProfile (student) {
    if (!student?.id) return
    router.push(`/students/${student.id}`)
  }

  function goToEdit (student) {
    if (!student?.id) return
    router.push(`/students/${student.id}?tab=info&edit=1`)
  }

  onMounted(() => {
    console.log('[students] useStudents mounted, calling fetchStudents once')
    fetchStudents()
  })

  return {
    students,
    loading,
    total,
    filters,
    fromDateInput,
    toDateInput,
    fetchStudents,
    resetFilters,
    onCreate,
    onRefresh,
    goToProfile,
    goToEdit,
    getInitials,
    formatNumber,
    formatDate
  }
}

/* =========================================================================
   فرم ساخت / ویرایش دانشجو
   ========================================================================= */
export function useStudentForm () {
  const router = useRouter()
  const route = useRoute()

  const loading = ref(false)
  const saving = ref(false)
  const form = reactive({
    id: null,
    first_name: '',
    last_name: '',
    full_name: '',
    phone: '',
    national_code: '',
    email: '',
    note: ''
  })

  const isEdit = computed(() => !!form.id)

  async function loadForEdit () {
    const id = route.params.id
    if (!id) return

    loading.value = true
    try {
      const res = await fetch(`${API_BASE}/api/students/${id}`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      })
      const data = await res.json()

      if (!res.ok) {
        console.warn('[student-form] load error', res.status, data)
        if (res.status === 401) {
          await router.push(`/auth/login?redirect=${encodeURIComponent(route.fullPath || '/students')}`)
        }
        return
      }

      Object.assign(form, data)
    } catch (err) {
      console.error('[student-form] loadForEdit error', err)
    } finally {
      loading.value = false
    }
  }

  async function save () {
    saving.value = true
    try {
      const method = isEdit.value ? 'PUT' : 'POST'
      const url = isEdit.value
        ? `${API_BASE}/api/students/${form.id}`
        : `${API_BASE}/api/students`

      const res = await fetch(url, {
        method,
        headers: getAuthHeaders(),
        credentials: 'include',
        body: JSON.stringify(form)
      })
      const data = await res.json()

      if (!res.ok) {
        console.warn('[student-form] save error', res.status, data)
        if (res.status === 401) {
          await router.push(`/auth/login?redirect=${encodeURIComponent(route.fullPath || '/students')}`)
        }
        return
      }

      await router.push('/students')
    } catch (err) {
      console.error('[student-form] save error', err)
    } finally {
      saving.value = false
    }
  }

  return {
    form,
    loading,
    saving,
    isEdit,
    loadForEdit,
    save
  }
}

/* =========================================================================
   پروفایل دانشجو
   ========================================================================= */
export function useStudentProfile () {
  const router = useRouter()
  const route = useRoute()

  const loading = ref(false)
  const student = ref(null)
  const activeTab = ref('overview')

  function setTab (tab) {
    activeTab.value = tab
  }

  async function fetchStudent () {
    const id = route.params.id
    if (!id) return

    loading.value = true
    try {
      const res = await fetch(`${API_BASE}/api/students/${id}`, {
        method: 'GET',
        headers: getAuthHeaders(),
        credentials: 'include'
      })
      const data = await res.json()

      console.log('[student-profile] status', res.status, data)

      if (!res.ok) {
        if (res.status === 401) {
          console.warn('[student-profile] 401 → login')
          await router.push(`/auth/login?redirect=${encodeURIComponent(route.fullPath || `/students/${id}`)}`)
        }
        return
      }

      student.value = data
    } catch (err) {
      console.error('[student-profile] fetch error', err)
    } finally {
      loading.value = false
    }
  }

  onMounted(fetchStudent)

  const displayName = computed(() => {
    if (!student.value) return ''
    return student.value.full_name ||
      `${student.value.first_name || ''} ${student.value.last_name || ''}`.trim()
  })

  return {
    student,
    loading,
    activeTab,
    setTab,
    fetchStudent,
    getInitials,
    formatNumber,
    formatDate,
    displayName
  }
}
